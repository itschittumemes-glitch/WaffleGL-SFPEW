# WaffleGL-SFPEW — External ANGLE borrowing patch

This patch adds the source-selection/persistence layer for borrowing ANGLE
libraries from supported installed launchers.

## Files

- `AngleProvider.kt` — discovers supported launchers and verifies both
  `libEGL_angle.so` and `libGLESv2_angle.so`.
- `AngleSourceStore.kt` — persists the selected launcher package name.
- `ANDROID_MANIFEST_QUERIES.xml` — Android 11+ package visibility entries.

## Required integration

1. Add the `<queries>` entries to the application's existing
   `AndroidManifest.xml`.
2. Add the two Kotlin files under the project's matching package/source tree.
3. Add a Settings UI that calls `AngleProvider.sources(context)` and lets the
   user select one source.
4. Persist only the package name with `AngleSourceStore`.
5. At runtime, resolve the selected package again with
   `PackageManager` and obtain its current `ApplicationInfo.nativeLibraryDir`.
6. Verify both ANGLE libraries before use.
7. Before the first `libmobileglues` load in the process, set:
   `MG_ANGLE_DIR=<resolved nativeLibraryDir>`.
8. Do not bundle `libEGL_angle.so` or `libGLESv2_angle.so` in this plugin.
9. Do not silently choose another app's ANGLE; selection should be explicit.

## Important

This is an integration patch, not a complete replacement of the project's
binary `MGLegacy-plugin-project.zip`. The actual launch/native initialization
code still has to pass `MG_ANGLE_DIR` early enough in the process.

Cross-app native-library loading is Android-version/linker-namespace dependent,
so availability should be treated as runtime-detectable rather than
guaranteed on every device.
