package com.fcl.plugin.mobileglues.settings

import android.content.Context
import java.io.File

data class AngleSource(
    val packageName: String,
    val label: String,
    val versionName: String?,
    val libraryDir: String,
)

object AngleProvider {
    const val GLES_LIBRARY = "libGLESv2_angle.so"
    const val EGL_LIBRARY = "libEGL_angle.so"

    private val KNOWN_LAUNCHERS = listOf(
        "com.tungsten.fcl",
        "com.tungsten.fcm",
        "com.tungsten.fcl.ngg",
        "com.tungsten.fcl.qualcommdr",
        "com.tungsten.fcl.mgdebug.debug",
        "com.movtery.zalithlauncher.v2",
        "com.movtery.zalithlauncher.v2.debug",
        "org.fcl.enchantnet",
    )

    fun sources(context: Context): List<AngleSource> {
        val pm = context.packageManager
        return KNOWN_LAUNCHERS.mapNotNull { packageName ->
            val info = runCatching { pm.getPackageInfo(packageName, 0) }.getOrNull()
                ?: return@mapNotNull null
            val appInfo = info.applicationInfo ?: return@mapNotNull null
            val dir = appInfo.nativeLibraryDir ?: return@mapNotNull null
            if (!hasAngle(dir)) return@mapNotNull null
            AngleSource(
                packageName = packageName,
                label = runCatching { pm.getApplicationLabel(appInfo).toString() }
                    .getOrDefault(packageName),
                versionName = info.versionName,
                libraryDir = dir,
            )
        }
    }

    fun hasAngle(directory: String?): Boolean {
        if (directory.isNullOrEmpty()) return false
        return listOf(EGL_LIBRARY, GLES_LIBRARY).all { name ->
            val file = File(directory, name)
            runCatching { file.isFile && file.canRead() }.getOrDefault(false)
        }
    }
}
