package com.fcl.plugin.mobileglues.settings

import android.content.Context
import androidx.core.content.edit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AngleSourceStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("plugin_config", Context.MODE_PRIVATE)
    private val selected = MutableStateFlow(
        prefs.getString(KEY_ANGLE_SOURCE, null)
    )
    val packageName: StateFlow<String?> = selected.asStateFlow()

    fun set(packageName: String?) {
        prefs.edit {
            if (packageName == null) remove(KEY_ANGLE_SOURCE)
            else putString(KEY_ANGLE_SOURCE, packageName)
        }
        selected.value = packageName
    }

    companion object {
        private const val KEY_ANGLE_SOURCE = "angle_source_package"
    }
}
